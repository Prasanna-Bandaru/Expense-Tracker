import React from 'react';

export const Header = () => {
  return (
    <div>Expense tracker</div>
  )
}
export default Header;
